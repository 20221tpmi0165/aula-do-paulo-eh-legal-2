datas = ("1968 21 4", "1962 10 18", "1945 12 4")
org_data = sorted(datas)
print(org_data)












