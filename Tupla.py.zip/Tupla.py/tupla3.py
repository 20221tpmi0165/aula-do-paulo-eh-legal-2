
cor = ("azul", "vermelho","preto","branco")
cor = sorted(cor)
print(cor)