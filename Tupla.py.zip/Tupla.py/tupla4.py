
num = (20, 5,11)
soma = sum(num)
print(soma)
