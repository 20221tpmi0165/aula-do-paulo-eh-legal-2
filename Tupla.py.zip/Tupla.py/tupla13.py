
tupla = (3,2,1,6,4,7)
for num in tupla:
    if num % 2 == 0:
        print(num)
    else:
        print("num_impar")


