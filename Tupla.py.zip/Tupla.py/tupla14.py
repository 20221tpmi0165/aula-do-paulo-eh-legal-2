numIn = (2,5,3,7,2,3,)
não_rep = tuple(set(numIn))
print(não_rep)