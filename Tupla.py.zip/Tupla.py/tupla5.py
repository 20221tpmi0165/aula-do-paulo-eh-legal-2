
num = (2,5,8,10)
num_maior = max(num)
num_menor = min(num)
print("O maior numero na tupla é:{} ".format(num_maior))
print("O menor numero na tupla é:{} ".format(num_menor))
