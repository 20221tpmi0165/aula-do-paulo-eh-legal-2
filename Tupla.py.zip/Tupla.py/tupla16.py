tupla_1 = (2,6,8)
tupla_2 = (4,3,1)
soma = sum(tupla_1 + tupla_2)
print(soma)