
num = (0,1, 2, 3, 4, 5, 6, 7, 8)
elementos_pares = tuple(num)
for numero in num:
    if numero % 2 == 0:
        print(numero)


