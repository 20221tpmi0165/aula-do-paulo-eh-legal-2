
palavra = ("canoa", "prato","Paloma")
for p in palavra:
    if len(p) > 5:
       print(p)



