nota = ("9","5","8","6","7")
tupla = tuple(sorted(nota))
print(tupla)