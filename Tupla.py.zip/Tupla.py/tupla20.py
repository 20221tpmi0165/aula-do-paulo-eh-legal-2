nomes = ("macaco", "cachorro","arara", "vaca","bode")
ordem_alfabetica = tuple(sorted(nomes[:3]))
print(ordem_alfabetica)









