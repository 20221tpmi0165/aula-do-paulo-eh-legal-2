tupla = (2,5,8,12,18,20)
for num in tupla:
    if num > 10:
        print(num)
    else:
        print("menor que 10")
    
