fruta = ("manga","lanranja", "mamão")
for elemento in fruta[1]:
    print(elemento)