
tuplVazia = ()
for tuplVazia in range(0,10):
    print(tuplVazia)

