
num = (1,2,3,30,4)
soma = sum(num)
quant = len(num)
media = soma/quant
print("quant é {}, a soma é {}, a media é {}, ".format(quant,soma,media))