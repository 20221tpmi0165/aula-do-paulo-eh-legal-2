
num = (6,8,10,20)
verifica = 3
if verifica in num:
    print(verifica)
else:
    print("não se encontra ") 