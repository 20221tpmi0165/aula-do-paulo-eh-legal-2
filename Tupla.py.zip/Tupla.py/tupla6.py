
tupla_1 = (10,20,30,)
tupla_2 = ( 2,4,6,8)
tupla_3 = tupla_1 + tupla_2
print(tupla_3)

